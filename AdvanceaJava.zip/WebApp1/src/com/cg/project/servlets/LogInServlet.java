package com.cg.project.servlets;
import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.beans.Associate;

import jdk.nashorn.internal.ir.RuntimeNode.Request;
@WebServlet("/LogIn")
public class LogInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public LogInServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int associateId=Integer.parseInt(req.getParameter("associateId"));
		String password=req.getParameter("password");
		
		Associate associate=new Associate(associateId, password);
		
		RequestDispatcher dispatcher;
		
		if(associate.getAssociateId()==1111&&associate.getPassword().equals("sasasa")){
			dispatcher=req.getRequestDispatcher("loginSuccessPage.jsp");
			req.setAttribute("associate",associate);
			dispatcher.forward(req, resp);
		}
		else{
			dispatcher=req.getRequestDispatcher("loginPage.jsp");
			req.setAttribute("errorMessage", "associateId or password is wrong");
			dispatcher.forward(req, resp);
		}
	}
	/*public void init(ServletConfig config) throws ServletException {
	}
	public void destroy() {
	}
	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		out.print("<html><head><meta charset=ISO-8859-1><title>SigUp</title></head><body><h1>Log in Page<br>This is servlet class for loging in</h1><form onsubmit=return fun()><input type=text placeholder=Enter User Name name=userName id=userName required><br><input type=password placeholder=Enter Password id=password name=password required><input type=submit value=Submit></form> </body></html>");
	}*/
}




