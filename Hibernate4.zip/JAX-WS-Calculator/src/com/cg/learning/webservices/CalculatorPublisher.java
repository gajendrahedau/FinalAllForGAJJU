package com.cg.learning.webservices;

import javax.xml.ws.Endpoint;
public class CalculatorPublisher {
	public static void main(String[] args) {
		//1st argument is the publication URI.
		//2nd argument is an SIB instance
		Endpoint.publish("http://127.0.0.1:6754/cs", new Calculator());
		
		System.out.println("Hello");
	}
}
