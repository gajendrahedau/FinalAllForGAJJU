package com.cg.payroll.daoservices;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import org.hibernate.sql.ordering.antlr.Factory;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;

public class MainClass {
	public static void main(String args[]){
		Associate associate=new Associate(1234, "Gaj", "Hedau", "A", "ASD", "ASDFG564A", "gaj@gmail.com", new BankDetails(123456, "SBI", "SBI78665"),new Salary(12345, 2345, 786));
		AssociateDAO associateDAO=new AssociateDAOImpl();
		associateDAO.save(associate);
	}
}
