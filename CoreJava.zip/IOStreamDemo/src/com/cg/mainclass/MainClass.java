package com.cg.mainclass;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.iodemo.SerializableDemo;

public class MainClass {
	public static void main(String args[]) throws FileNotFoundException, IOException, ClassNotFoundException{
		/*File file1=new File("D:\\159877_Gajendra_hedau\\demo.txt");
		if(!file1.exists())
		java.sql
			file1.createNewFile();
		File file2=new File("");
		SerializableDemo.doSerialization(file1);
		SerializableDemo.doDesirialization(file1);*/
		
		Properties projectProperties=new Properties();
		projectProperties.load(new FileInputStream(new File(".\\resources\\projectProperties.properties")));
		
		String projectKey1=projectProperties.getProperty("projectKey1");
		String projectKey2=projectProperties.getProperty("projectKey2");
		System.out.println(projectKey1+""+projectKey2);
		
	}
}
