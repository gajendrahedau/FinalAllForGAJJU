package com.cg.project.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.project.exception.InvalidNumberRangeException;
import com.cg.project.matservices.MathServices;
import com.cg.project.matservices.MathServicesImpl;

public class MathServicesTest {
	static MathServices mathServices;
	
	@BeforeClass
	public static void setUPTestEnv(){
		mathServices=new MathServicesImpl();
	}
	@Before
	public void setUpMockDataForTest(){
		
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForFirstNoInvalid() throws InvalidNumberRangeException{
		mathServices.addNums(-100, 200);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddNumbersForSecondNoInvalid() throws InvalidNumberRangeException{
		mathServices.addNums(100,-200);
	}
	@Test()
	public void testAddNumbersForBothNoInvalid() throws InvalidNumberRangeException{
		int expectedAns=300;
		int actualAns=mathServices.addNums(100, 200);
		Assert.assertEquals(expectedAns, actualAns);
	}
	@After
	public void tearDownMockDataForTest(){
		
	}
	@AfterClass
	public static void setDownTestEnv(){
		mathServices=null;
	}
}
