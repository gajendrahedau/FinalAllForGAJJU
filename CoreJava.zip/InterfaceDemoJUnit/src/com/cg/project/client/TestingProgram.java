package com.cg.project.client;

import static java.lang.System.*;

import static java.lang.Integer.MAX_VALUE;

public class TestingProgram {
	
	static String[] str=new String[50];
	public static void main(String[] args) {
		System.out.println("Hello World");
		out.println("Hello World2");
		int a=10,b=2;
		int c=a&b;
		System.out.println(c);
		Car car=new Car();
		car.setTyres(5);
		System.out.println(car.getTyres());
		
	}

}
