package com.cg.project.client;

import com.cg.project.exception.InvalidNumberRangeException;
import com.cg.project.matservices.MathServices;
import com.cg.project.matservices.MathServicesImpl;


public class MainClass {

	public static void main(String[] args) {
		MathServices services=new MathServicesImpl();
		services.multiNums(10, 20);
		
		
		try {
			services.addNums(20, 40);
		} catch (InvalidNumberRangeException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
