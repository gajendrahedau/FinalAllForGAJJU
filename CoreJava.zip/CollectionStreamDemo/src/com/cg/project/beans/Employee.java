package com.cg.project.beans;

import java.util.ArrayList;
import java.util.stream.Stream;

public class Employee {
	String name;
	int id,salary;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public Employee(int id, int salary,String name) {
		this.name = name;
		this.id = id;
		this.salary = salary;
	}
	public static void main(String[] args){
		ArrayList<Employee> empList=new ArrayList<>();
		empList.add(new Employee(89,15000,"Satish"));
		empList.add(new Employee(179,15000,"Manoj"));
		empList.add(new Employee(134,15000,"Raj"));
		empList.add(new Employee(109,567000,"Mahendra"));
		empList.add(new Employee(1045,91000,"Jitendra"));
		empList.add(new Employee(1045,91000,"Jitendra"));
		empList.add(new Employee(109,50,"Bhajendra"));
		empList.add(new Employee(108,8000,"Atulendra"));
		empList.add(new Employee(109,5000,"Anuvendra"));
		
		
		empList.stream()
		.distinct()
		.filter(e->e.getName().startsWith("A"))
		.forEach(emp->System.out.println(emp));
		
		long count=empList.stream()
				.distinct()
				.count();
		System.out.println(count +"  "+empList.size());
		
		Stream<Employee> stream1=empList.stream();
		Stream<Employee> stream2=stream1.distinct();
		Stream<Employee> stream3=stream2.filter((emp)->emp.getName().startsWith("N"));
		stream3.forEach(emp->System.out.println(emp));
	}
	@Override
	public String toString() {
		return "Employee [name=" + name + ", id=" + id + ", salary=" + salary
				+ "]";
	}
}
