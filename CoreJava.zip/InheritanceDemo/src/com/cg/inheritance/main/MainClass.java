package com.cg.inheritance.main;

import com.cg.inheritance.beans.CEmployee;
import com.cg.inheritance.beans.Employee;
import com.cg.inheritance.beans.PEmployee;

public class MainClass {

	public static void main(String[] args) {
		
		/*Employee employee=new Employee(101, "ATUL", "ANAND", 20000);
		employee.calculateTotalSalary();
		
		System.out.println(employee.toString());
		*/
		
		Employee employee;
		
		employee=new PEmployee(102, "SATISH", "KUMAR", 15000);
		 employee.calculateTotalSalary();
		
		System.out.println( employee);
		
		 employee=new CEmployee(103, "ASHUTOSH", "KUMAR", 500);
		 CEmployee cemp;
		 cemp=(CEmployee)employee;
		 cemp.signContract();
		 employee.calculateTotalSalary();
	
	System.out.println(employee);
	}

}
