package com.cg.inheritance.beans;

public class CEmployee extends Employee{
	private int noOfHrs,variablePay;

	public CEmployee() {}

	public CEmployee(int employeeId, String firsName, String lastName,
			int noOfHrs) {
		super(employeeId, firsName, lastName, noOfHrs);
		this.noOfHrs=noOfHrs;
	}
	
	public void signContract(){
		System.out.println("Sign Contracted");
	}
	
	
	@Override
	public void calculateTotalSalary() {
		variablePay=noOfHrs*2000;
		this.setTotalSalary(variablePay);
	}

	@Override
	public String toString() {
		return super.toString()+" noOfHour=" + noOfHrs + ", variablePay="
				+ variablePay;
	}
	
	
	
}
