package com.cg.project.beans;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class ProductName{
	public static void main(String... args){
		  String []product=new String[10];
		product[0]="Hard Drive";
		product[1]="Laptop";
		product[2]="Printer";
		product[3]="Wire";
		product[4]="Mobile";
		product[5]="DVD";
		product[6]="Airtel";
		product[7]="Ear Phone";
		for (String string : product) 
			if(string!=null)
			System.out.println(string);
		Arrays.sort(product,new SortThroughComparator());
		System.out.println("Product name after sort");
		for (String string : product) 
			if(string!=null)
			System.out.println(string);
		
		ArrayList aList=new ArrayList<>(Arrays.asList(product));
		System.out.println("Conversion of ArrayList from Array");
		Collections.sort(aList,new SortThroughComparator());
		for (Object object : aList) {
			System.out.println(object);
		}
	}
}



