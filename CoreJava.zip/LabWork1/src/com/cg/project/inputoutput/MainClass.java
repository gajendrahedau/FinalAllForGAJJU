package com.cg.project.inputoutput;

import java.io.FileNotFoundException;
import java.io.IOException;

public class MainClass {
	public static void main(String[] args) throws IOException {
		System.out.println("h");
		ReadingWritingContent.readingContent();
	}

}
