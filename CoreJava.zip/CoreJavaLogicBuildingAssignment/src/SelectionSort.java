class SelectionSort{
	public static void main(String args[]){
		int numbers[]={12,21,23,41,7,2,10,34};
		
		int n = numbers.length;  
        for (int i = 0; i < n-1; i++) 
        {  
            int min_idx = i; 
            for (int j = i+1; j < n; j++) 
                if (numbers[j] < numbers[min_idx]) 
                    min_idx = j; 
			int temp = numbers[min_idx]; 
            numbers[min_idx] = numbers[i]; 
            numbers[i] = temp; 
        } 
		for (int i = 0; i < n; i++)
			System.out.print(numbers[i]+",");
	}
	
}