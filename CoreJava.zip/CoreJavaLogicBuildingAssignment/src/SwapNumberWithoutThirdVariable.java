public class SwapNumberWithoutThirdVariable {
	public static void main(String[] args) {
		int n1=10,n2=56;
		System.out.println("Number before swapping\n n1="+n1+"\nn2="+n2);
		n1=n1+n2;
		n2=n1-n2;
		n1=n1-n2;
		System.out.println("Number after swapping\n n1="+n1+"\nn2="+n2);
	}
}