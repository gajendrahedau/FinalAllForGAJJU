public class PalindromeNumber {
	public static void main(String[] args) {
		int number=5666;
		int p,find=0,temp;
		p=number;
		while(p>0){
			temp=p%10;
			find=find*10+temp;
			p=p/10;
		}
		if(find==number)
		System.out.println("The given no. is a palindrome");
		else
		System.out.println("The given no. is not a palindrome");
	}
}