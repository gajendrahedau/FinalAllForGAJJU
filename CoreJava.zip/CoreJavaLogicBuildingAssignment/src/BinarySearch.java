public class BinarySearch {
	public static void main(String[] args) {
		int array[]={3,5,8,9,12,22,34,45,67,78};
		int middle,first,last,key,n;
		key=67;
		n=array.length;
		first=0;
		last=n-1;
		middle=(first+last)/2;
		while(first<last){
			if(array[middle]==key){
				System.out.println("The element is found at "+(middle+1)+" position");
				break;
			}
			else if(key<array[middle]){
				last=middle-1;
				middle=(first+last)/2;
			}
			else{
				first=middle+1;
				middle=(first+last)/2;
			}
		}
		if(first>last)
			System.out.println("The element is not found in the array");
	}
}

