class CountOddEvenArmstrongPalindrome{
	public static void main(String args[]){
		int a=100,b=200,even=0,odd=0,armstrong=0,sum=0,palindrome=0;
		for(int i=a;i<=b;i++){	//for odd and even
			if(i%2==0)
				even++;
			else 
				odd++;
		}
		for(int i=a;i<=b;i++){	//for palindrome
			int number=i;
			sum=0;
			while(number>0){
				int mod=number%10;
				sum=sum*10+mod;
				number/=10;
			}
			if(sum==i)
				palindrome++;
		}
		for(int i=a;i<=b;i++){	//for armstrong
			int number=i;
			sum=0;
			while(number>0){
				int mod=number%10;
				sum=sum+mod*mod*mod;
				number/=10;
				}
				if(sum==i)
					armstrong++;
		}
		System.out.println("Count of Odd Number : "+odd);
		System.out.println("Count of Even Number : "+even);
		System.out.println("Count of Armstrong Number : "+armstrong);
		System.out.println("Count of Palindrome Number : "+palindrome);
		
	}
}
