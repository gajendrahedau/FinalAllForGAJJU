class BinaryToDecimal {
	public static void main(String args[]){
			String binaryString="010011";
			System.out.println("Output: "+Integer.parseInt(binaryString,2));
	    }
}


