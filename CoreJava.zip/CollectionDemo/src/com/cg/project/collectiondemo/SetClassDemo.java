package com.cg.project.collectiondemo;

import java.util.ArrayList;
import java.util.HashSet;

import com.cg.project.beans.Associate;

public class SetClassDemo {
	public static void setClassWork(){
		HashSet<Associate> strList=new HashSet<>();
		
		//insert
		strList.add(new Associate(101, 10000000, "Gajendra"));
		strList.add(new Associate(104, 400, "Atul"));
		strList.add(new Associate(107, 10500, "Ashutosh"));
		strList.add(new Associate(102, 500, "Anureet"));
		strList.add(new Associate(107, 10500, "Ashutosh"));
		
		for (Associate associate : strList) 
			System.out.println(associate);
		
		//searching
		System.out.println(strList.contains(new Associate(102, 500, "Anureet")));
	}

}
