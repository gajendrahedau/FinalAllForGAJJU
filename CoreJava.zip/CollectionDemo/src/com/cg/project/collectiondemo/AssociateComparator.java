package com.cg.project.collectiondemo;

import java.util.Comparator;

import com.cg.project.beans.Associate;

public class AssociateComparator implements Comparator<Associate> {
	public int compare(Associate a1,Associate a2){
		return a1.getSalary()-a2.getSalary();
		//return a1.getName().compareTo(a2.getName());
	}

}
