package com.cg.project.collectiondemo;

import java.util.ArrayList;
import java.util.Collections;

import com.cg.project.beans.Associate;

public class ListClassesDemo {
	
	public static void arrayListClassWork(){
		ArrayList<String> strList=new ArrayList<>();
		
		/*
		//insert
		strList.add("Satish");
		strList.add("Kumar");
		strList.add("Gajendra");
		strList.add("aedau");
		
		//searching
		System.out.println(strList.contains("Kumar"));
		System.out.println(strList.indexOf("Kumar"));
		
		//sorting
		Collections.sort(strList);
		
		//iteration
		for(String name: strList)
			System.out.println(name);
		*/
		
		ArrayList<Associate> associateList=new ArrayList<>();
		associateList.add(new Associate(101, 15000, "Gajendra"));
		associateList.add(new Associate(103, 185000, "Kumar"));
		associateList.add(new Associate(102, 4000, "Rakesh"));
		associateList.add(new Associate(104, 1000, "Nilesh"));
		
		Associate associateToBeSearch=new Associate(102, 4000, "Rakesh");
			
		System.out.println(associateList.indexOf(associateToBeSearch));
		System.out.println(associateList.contains(associateToBeSearch));
		
		for (Associate associate : associateList)
			if(associate.getAssociateId()==103 && associate.getName().equals("Kumar"))
				System.out.println(associate);
			
			
		Collections.sort(associateList);
		for (Associate associate1: associateList)
			System.out.println(associate1);
		System.out.println(" ");
		
		Collections.sort(associateList, new AssociateComparator());
		for (Associate associate1: associateList)
			System.out.println(associate1);
			
		
		
	}
	public static void linkedListClassWork(){
		
	}
	
}
