package com.cg.thread.main;
import com.cg.thread.beans.OddEvenThread;
import com.cg.thread.beans.RunnableResiurces;
public class MainClass {
	public static void main(String[] args) {
		/*RunnableResiurces r1=new RunnableResiurces();
		Thread th1=new Thread(r1,"abc");
		Thread th2=new Thread(r1,"pqr");
		th1.start();
		th2.start();*/
		/*OddEvenThread oddEvenThread1=new OddEvenThread("odd");
		OddEvenThread oddEvenThread2=new OddEvenThread("even");
		oddEvenThread1.start();
		oddEvenThread2.start();*/
	}
}
