package com.cg.thread.beans;
public class OddEvenThread extends Thread{
	public OddEvenThread(String string) {
		super(string);
	}
	@Override
	public void run() {
		if(this.getName().equals("odd")){
			for(int i=1;i<=100;i++)
				if(i%2==1)
					System.out.println("Odd Thread"+i);
		}
		else if(this.getName().equals("even")){
			for(int i=1;i<=100;i++)
				if(i%2==0)
					System.out.println("Even Thread"+i);
		}
	}
}
