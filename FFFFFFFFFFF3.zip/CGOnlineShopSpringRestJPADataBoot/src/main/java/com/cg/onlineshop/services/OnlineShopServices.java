package com.cg.onlineshop.services;

import java.util.List;

import com.cg.onlineshop.beans.Product1;
import com.cg.onlineshop.exception.ProductDetailsNotFoundException;

public interface OnlineShopServices {
	public Product1 acceptProductDetails(Product1 product);
	public List<Product1> getAllProductDetails();
	public Product1 getProductDetails(int productId) throws ProductDetailsNotFoundException;
	public void removeProductDetails(int productId);
}
