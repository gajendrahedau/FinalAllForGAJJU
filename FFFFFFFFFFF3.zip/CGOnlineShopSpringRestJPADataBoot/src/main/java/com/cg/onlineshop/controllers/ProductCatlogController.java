package com.cg.onlineshop.controllers;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.onlineshop.beans.Product1;
import com.cg.onlineshop.exception.ProductDetailsNotFoundException;
import com.cg.onlineshop.services.OnlineShopServices;

@RestController
@CrossOrigin
public class ProductCatlogController {

	@Autowired
	OnlineShopServices onlineShopServices;

	@RequestMapping(value="/hello")
	public ResponseEntity<String>sayHello(){
		ResponseEntity<String>response=new ResponseEntity<String>("Hello To ALL", HttpStatus.OK);
		return response;
	}

/*	@RequestMapping(
			value="/acceptProductDetails",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE
			)
	public ResponseEntity<String> acceptProductDetails(@RequestParam("productId") int productId,@RequestParam("productCode") int productCode,@RequestParam("price") int price,@RequestParam("starRating") int starRating,@RequestParam("description") String description,
			@RequestParam("productName") String productName,@RequestParam("releaseDate") String releaseDate){
		Product product=new Product(productId, productCode, price, starRating, description, productName, releaseDate);
		onlineShopServices.acceptProductDetails(product);
		System.out.println("Yes");
		return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}*/
	@RequestMapping(
			value="/acceptProductDetails",
			method=RequestMethod.POST,
			consumes=MediaType.APPLICATION_JSON_VALUE
			)
	public ResponseEntity<String> acceptProductDetails(@RequestBody Product1 product){
		onlineShopServices.acceptProductDetails(product);
		System.out.println("Yes");
		return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}

	@RequestMapping(
			value="/getProductDetails",
			produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json"
			)
	public ResponseEntity<Product1> getProductDetails(@RequestParam("productId") int productId) throws ProductDetailsNotFoundException{
		Product1 product=onlineShopServices.getProductDetails(productId);
		return new ResponseEntity<>(product,HttpStatus.OK);
	}

	@RequestMapping(
			method=RequestMethod.GET, 
			value= {"/allProductDetails"},
			produces=MediaType.APPLICATION_JSON_VALUE,
			headers="Accept=application/json"
			)
	public ResponseEntity<List<Product1>> getAllProductDetails() {
		List<Product1>productList=onlineShopServices.getAllProductDetails();
		return new ResponseEntity<>(productList,HttpStatus.OK);
	}

	@RequestMapping(
			value="/deleteProductDetails",
			method=RequestMethod.DELETE
			)
	public ResponseEntity<String> deleteProductDetails(@RequestParam("productId") int productId) {
		onlineShopServices.removeProductDetails(productId);
		return new ResponseEntity<>("Product details with productCode "+productId+"successfully deleted",HttpStatus.OK);
	}
	
	@RequestMapping(
			value="/addBulkProductDetails",
			consumes=MediaType.APPLICATION_JSON_VALUE,
			method=RequestMethod.POST
			)
	public ResponseEntity<String> addBulkProductDetails(@RequestBody ArrayList<Product1> products){
		for (Product1 product : products)
			onlineShopServices.acceptProductDetails(product);
			return new ResponseEntity<>("Product details successfully added",HttpStatus.OK);
	}
}







