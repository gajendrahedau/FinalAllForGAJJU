package com.cg.payroll.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GetAssociateDetailsPage {
	@FindBy(how=How.NAME,name="associateID")
	private WebElement associateID;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;
	@FindBy(how=How.XPATH,xpath="html/body/div/table/tbody/tr[4]/td")
	private WebElement actualMessage;
	public GetAssociateDetailsPage() {}
	public String getAssociateID() {
		return associateID.getAttribute("value");
	}
	public void setAssociateID(String associateID) {
		this.associateID.sendKeys(associateID);
	}
	public String getActualMessage() {
		return actualMessage.getText();
	}
	public void click() {
		 submit.click();
	}
	public void submit() {
		submit.submit();
	}
}
