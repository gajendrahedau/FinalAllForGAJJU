package com.cg.payroll.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;
import com.cg.payroll.beans.CalculateNetSalary;
import com.cg.payroll.beans.GetAssociateDetailsPage;
import com.cg.payroll.beans.RegisterAssociatePage;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class PayrollServiceStepDefinition {
	private GetAssociateDetailsPage getAssociateDetailsPage;
	private CalculateNetSalary calculateNetSalary;
	private RegisterAssociatePage registerAssociatePage;
	private WebDriver driver;
	@Given("^User is on 'Payroll registration page'$")
	public void user_is_on_Payroll_registration_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/registrationPage");
		registerAssociatePage=PageFactory.initElements(driver, RegisterAssociatePage.class);
	}

	@When("^User enters invalid credentials for registering$")
	public void user_enters_invalid_credentials_for_registering() throws Throwable {
	    registerAssociatePage.setFirstName("Gajendra");
	    registerAssociatePage.setLastName("Hedau");
	    registerAssociatePage.setDesignation("");
	    registerAssociatePage.setDepartment("");
	    registerAssociatePage.setEmailId("gaj@gmail.com");
	    registerAssociatePage.setBankName("HDFC");
	    registerAssociatePage.setPancard("ASDFG24545A");
	    registerAssociatePage.setIfscCode("HDFC0083");
	    registerAssociatePage.setAccountNumber("1234");
	    registerAssociatePage.setBasicSalary("40000");
	    registerAssociatePage.setEpf("2000");
	    registerAssociatePage.setCompanyPf("3000");
	    registerAssociatePage.click();
	}

	@Then("^'Field cannot be empty' message should be displayed$")
	public void field_cannot_be_empty_message_should_be_displayed() throws Throwable {
		String actual="Registration";
		String expected=driver.getTitle();
		Assert.assertEquals(expected, actual);
		driver.close();
	}

	@When("^User enters valid credentials for registering$")
	public void user_enters_valid_credentials_for_registering() throws Throwable {
		registerAssociatePage.setFirstName("Gajendra");
	    registerAssociatePage.setLastName("Hedau");
	    registerAssociatePage.setDesignation("Sr. Con");
	    registerAssociatePage.setDepartment("A");
	    registerAssociatePage.setEmailId("gaj@gmail.com");
	    registerAssociatePage.setBankName("HDFC");
	    registerAssociatePage.setPancard("ASDFG3455AA");
	    registerAssociatePage.setIfscCode("HDFC8787");
	    registerAssociatePage.setAccountNumber("12345");
	    registerAssociatePage.setBasicSalary("50000");
	    registerAssociatePage.setEpf("3000");
	    registerAssociatePage.setCompanyPf("5000");
	    registerAssociatePage.click();
	}

	@Then("^User should be displayed with User ID$")
	public void user_should_be_displayed_with_User_ID() throws Throwable {
		String actual="Registration Success Page";
		String expected=driver.getTitle();
		Assert.assertEquals(expected, actual);
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}

	@Given("^User is on 'Get Associate details page'$")
	public void user_is_on_Get_Associate_details_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/getAssociateDetailsPage");
		getAssociateDetailsPage=PageFactory.initElements(driver, GetAssociateDetailsPage.class);
	}

	@When("^User enters Invalid credentials$")
	public void user_enters_Invalid_credentials() throws Throwable {
		getAssociateDetailsPage.setAssociateID("3546");
		getAssociateDetailsPage.click();
	}

	@Then("^User should be asked to enter associate ID again$")
	public void user_should_be_asked_to_enter_associate_ID_again() throws Throwable {
	   //getAssociateDetailsPage
		String actual="getAssociateDetailsPage";
		String expected=driver.getTitle();
		Assert.assertEquals(expected, actual);
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}

	@When("^User enters valid Associate ID$")
	public void user_enters_valid_Associate_ID() throws Throwable {
		getAssociateDetailsPage.setAssociateID("1");
		getAssociateDetailsPage.click();
	}

	@Then("^User should get information of that associate$")
	public void user_should_get_information_of_that_associate() throws Throwable {
		String actual="gaj@gmail.com";
		String expected=getAssociateDetailsPage.getActualMessage();
		Assert.assertEquals(expected, actual);
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}

	@Given("^User is on 'Get net salary page'$")
	public void user_is_on_Get_net_salary_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:4444/calculateNetSalaryPage");
		calculateNetSalary=PageFactory.initElements(driver, CalculateNetSalary.class);
	}

	@When("^User enters valid Associate ID for getting net salary$")
	public void user_enters_valid_Associate_ID_for_getting_net_salary() throws Throwable {
	  calculateNetSalary.setAssociateID("1");
	  calculateNetSalary.click();
	}
	@Then("^User should get Net Salary$")
	public void user_should_get_Net_Salary() throws Throwable {
		String actual="Calculate Net Salary Page";
		String expected=driver.getTitle();
		Assert.assertEquals(expected, actual);
		System.out.println(driver.getCurrentUrl());
		driver.close();
	}


}
