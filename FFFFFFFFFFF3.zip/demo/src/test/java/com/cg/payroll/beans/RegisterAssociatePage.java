package com.cg.payroll.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class RegisterAssociatePage {
	@FindBy(how=How.NAME,name="firstName")
	private WebElement firstName;
	@FindBy(how=How.NAME,name="lastName")
	private WebElement lastName;
	@FindBy(how=How.NAME,name="department")
	private WebElement department;
	@FindBy(how=How.NAME,name="designation")
	private WebElement designation;
	@FindBy(how=How.NAME,name="pancard")
	private WebElement pancard;
	@FindBy(how=How.NAME,name="emailId")
	private WebElement emailId;
	@FindBy(how=How.NAME,name="bankdetails.accountNumber")
	private WebElement accountNumber;
	@FindBy(how=How.NAME,name="bankdetails.bankName")
	private WebElement bankName;
	@FindBy(how=How.NAME,name="bankdetails.ifscCode")
	private WebElement ifscCode;
	@FindBy(how=How.NAME,name="salary.epf")
	private WebElement epf;
	@FindBy(how=How.NAME,name="salary.companyPf")
	private WebElement companyPf;
	@FindBy(how=How.NAME,name="salary.basicSalary")
	private WebElement basicSalary;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;
	public RegisterAssociatePage() {}
	public String getFirstName() {
		return firstName.getAttribute("value");
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public String getLastName() {
		return lastName.getAttribute("value");
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public String getDepartment() {
		return department.getAttribute("value");
	}
	public void setDepartment(String department) {
		this.department.sendKeys(department);
	}
	public String getDesignation() {
		return designation.getAttribute("value");
	}
	public void setDesignation(String designation) {
		this.designation.sendKeys(designation);
	}
	public String getPancard() {
		return pancard.getAttribute("value");
	}
	public void setPancard(String pancard) {
		this.pancard.sendKeys(pancard);
	}
	public String getEmailId() {
		return emailId.getAttribute("value");
	}
	public void setEmailId(String emailId) {
		this.emailId.sendKeys(emailId);
	}
	public String getAccountNumber() {
		return accountNumber.getAttribute("value");
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber.sendKeys(accountNumber);
	}
	public String getBankName() {
		return bankName.getAttribute("value");
	}
	public void setBankName(String bankName) {
		this.bankName.sendKeys(bankName);;
	}
	public WebElement getIfscCode() {
		return ifscCode;
	}
	public void setIfscCode(String ifscCode) {
		this.ifscCode.sendKeys(ifscCode);
	}
	public String getEpf() {
		return epf.getAttribute("value");
	}
	public void setEpf(String epf) {
		this.epf.sendKeys(epf);
	}
	public String getCompanyPf() {
		return companyPf.getAttribute("value");
	}
	public void setCompanyPf(String companyPf) {
		this.companyPf.sendKeys(companyPf);
	}
	public String getBasicSalary() {
		return basicSalary.getAttribute("value");
	}
	public void setBasicSalary(String basicSalary) {
		this.basicSalary.sendKeys(basicSalary);
	}
	public void click() {
		 submit.click();
	}
	public void submit() {
		submit.submit();
	}
}
