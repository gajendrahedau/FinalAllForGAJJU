package com.cg.payroll.beans;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class CalculateNetSalary {
	@FindBy(how=How.NAME,name="associateID")
	private WebElement associateID;
	@FindBy(how=How.NAME,name="submit")
	private WebElement submit;
	public CalculateNetSalary() {}
	public String getAssociateID() {
		return associateID.getAttribute("value");
	}
	public void setAssociateID(String associateID) {
		this.associateID.sendKeys(associateID);
	}
	public void click() {
		 submit.click();
	}
	public void submit() {
		submit.submit();
	}
}
