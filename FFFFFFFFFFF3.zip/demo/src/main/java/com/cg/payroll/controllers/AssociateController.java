package com.cg.payroll.controllers;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class AssociateController {
	
	@Autowired
	private PayrollServices payrollServices;
	
	@RequestMapping("/registerAssociate")
	public ModelAndView registerAssociateAction(@Valid @ModelAttribute Associate associate,
			BindingResult result,HttpSession session) throws PayrollServicesDownException {
		if(result.hasErrors()) 
			return new ModelAndView("registrationPage");
		associate=payrollServices.acceptAssociateDetails(associate);
		session.setAttribute("associate", associate);
		return new ModelAndView("registrationSuccessPage","associate",associate);
	}
	@RequestMapping("/calculateNetSalaryWithID")
	public ModelAndView calculateNetSalary(@RequestParam("associateID") int associateID) {
		int netSalary=0;
		try {
			netSalary=payrollServices.calculateNetSalary(associateID);
			return new ModelAndView("calculateNetSalaryPage","netSalary","Your Net Salary is "+netSalary+".");
		} catch (AssociateDetailsNotFoundException | PayrollServicesDownException e) {
			return new ModelAndView("calculateNetSalaryPage","netSalary",e.getMessage());
		}
	}
	@RequestMapping("/getAssociateDetails")
	public ModelAndView getAssociateDetails(@RequestParam("associateID") int associateID) {
		Associate associate=null;
		try {
			associate=payrollServices.getAssociateDetails(associateID);
			return new ModelAndView("getAssociateDetails","associate",associate);
		} catch (AssociateDetailsNotFoundException | PayrollServicesDownException e) {
			return new ModelAndView("getAssociateDetailsPage","associates",e.getMessage());
		}
	}
	@RequestMapping("/logIn")
	public ModelAndView logIn(@RequestParam("associateID") int associateID,@RequestParam("accountNumber") int accountNumber,HttpSession session) {
		try {
			Associate associate=payrollServices.getAssociateDetails(associateID);
			if(associate.getBankdetails().getAccountNumber()==accountNumber) {
				session.setAttribute("associate",associate);
				return new ModelAndView("registrationSuccessPage","associate",associate);
			}
			else 
				return new ModelAndView("logInPage","associates","Sorry!! Account Number is Incorrect. Please try again");
		} catch (PayrollServicesDownException | AssociateDetailsNotFoundException e) {
			return new ModelAndView("logInPage","associates",e.getMessage());
		}
	}
}
