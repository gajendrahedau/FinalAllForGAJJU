package com.cg.payroll.controllers;

import java.util.ArrayList;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.exceptions.PayrollServicesDownException;
import com.cg.payroll.services.PayrollServices;

@Controller
public class URIController {

	Associate associate;
	@Autowired
	PayrollServices payrollServices;

	@RequestMapping("/")
	public String getIndexPage(){
		return "indexPage";
	}
	@RequestMapping("/logInPage")
	public String logInPage(){
		return "logInPage";
	}
	@RequestMapping("/registrationPage")
	public String getRegistrationPage() {
		return "registrationPage";
	}
	@RequestMapping("/calculateNetSalary")
	public ModelAndView calculateNetSalary(HttpSession session) {
		int netSalary=0;
		try {
			Associate associate=(Associate)session.getAttribute("associate");
			netSalary=payrollServices.calculateNetSalary(associate.getAssociateID());
			return new ModelAndView("registrationSuccessPage","netSalary",netSalary);
		} catch (AssociateDetailsNotFoundException | PayrollServicesDownException e) {
			return new ModelAndView("registrationSuccessPage","netSalary",e.getMessage());
		}
	}
	@RequestMapping("/getAssociateDetailsPage")
	public String getAssociateDetailsPage() {
		return "getAssociateDetailsPage";
	}
	@RequestMapping("/calculateNetSalaryPage")
	public String calculateNetSalaryPage() {
		return "calculateNetSalaryPage";
	}
	//
	@RequestMapping("/getAllAssociateDetailsPage")
	public ModelAndView getAllAssociateDetailsPage() {
		try {
			ArrayList<Associate> associates=payrollServices.getAllAssociateDetails();
			return new ModelAndView("getAllAssociateDetailsPage","associates",associates);
		} catch (PayrollServicesDownException e) {
			return new ModelAndView("getAllAssociateDetailsPage","associates",e.getMessage());
		}
	}
	@ModelAttribute
	public Associate getAssociate() {
		associate=new Associate();
		return associate;
	}
}
