package com.cg.mobilebilling.services;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import com.cg.mobilebilling.beans.Bill;
import com.cg.mobilebilling.beans.Customer;
import com.cg.mobilebilling.beans.Plan;
import com.cg.mobilebilling.beans.PostpaidAccount;
import com.cg.mobilebilling.daoservices.BillingDAOServices;
import com.cg.mobilebilling.daoservices.CustomerDAOServices;
import com.cg.mobilebilling.daoservices.PlanDAOServices;
import com.cg.mobilebilling.daoservices.PostPaidDAOServices;
import com.cg.mobilebilling.exceptions.BillDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.BillingServicesDownException;
import com.cg.mobilebilling.exceptions.CustomerDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.InvalidBillMonthException;
import com.cg.mobilebilling.exceptions.PlanDetailsNotFoundException;
import com.cg.mobilebilling.exceptions.PostpaidAccountNotFoundException;
@Component("billingServices")
public class BillingServicesImpl implements BillingServices {
	@Autowired
	private BillingDAOServices billingDAOServices;
	@Autowired
	private PostPaidDAOServices postPaidDAOServices;
	@Autowired
	private CustomerDAOServices customerDAOServices;
	@Autowired
	private PlanDAOServices planDAOServices; 
	@Override
	public List<Plan> getPlanAllDetails() throws BillingServicesDownException {
		return planDAOServices.findAll();
	}

	@Override
	public Customer acceptCustomerDetails(Customer customer)
			throws BillingServicesDownException {
		customer=customerDAOServices.save(customer);
				return customer;
	}

	@Override
	public long openPostpaidMobileAccount(int customerID, int planID)
			throws PlanDetailsNotFoundException, CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).get();
		if(customer==null) throw new CustomerDetailsNotFoundException("Customer with customer id "+customerID+" does not exist");
		Plan plan=planDAOServices.findById(planID).get();
		if(plan==null) throw new PlanDetailsNotFoundException("Plan with plan id "+planID+" does not exist");
		PostpaidAccount postpaidAccount=new PostpaidAccount(plan, customer);
		postpaidAccount=postPaidDAOServices.save(postpaidAccount);
		return postpaidAccount.getMobileNo();
	}

	@Override
	public int generateMonthlyMobileBill(int customerID, long mobileNo, String billMonth, int noOfLocalSMS,
			int noOfStdSMS, int noOfLocalCalls, int noOfStdCalls, int internetDataUsageUnits)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillingServicesDownException, PlanDetailsNotFoundException {
		getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount=getPostPaidAccountDetails(customerID, mobileNo);
		float localSMSAmount=((noOfLocalSMS-postpaidAccount.getPlan().getFreeLocalSMS())>0)?((noOfLocalSMS-postpaidAccount.getPlan().getFreeLocalSMS())*(postpaidAccount.getPlan().getLocalSMSRate())):0.0f;
		float stdSMSAmount=((noOfStdSMS-postpaidAccount.getPlan().getFreeStdSMS())>0)?((noOfStdSMS-postpaidAccount.getPlan().getFreeStdSMS())*(postpaidAccount.getPlan().getLocalSMSRate())):0.0f;
		float localCallAmount=((noOfLocalCalls-postpaidAccount.getPlan().getFreeLocalCalls())>0)?((noOfLocalCalls-postpaidAccount.getPlan().getFreeLocalCalls())*(postpaidAccount.getPlan().getLocalCallRate())):0.0f;
		float stdCallAmount=((noOfStdCalls-postpaidAccount.getPlan().getFreeStdCalls())>0)?((noOfStdCalls-postpaidAccount.getPlan().getFreeStdCalls())*(postpaidAccount.getPlan().getStdCallRate())):0.0f;
		float internetDataUsageAmount=((internetDataUsageUnits-postpaidAccount.getPlan().getFreeInternetDataUsageUnits())>0)?((internetDataUsageUnits-postpaidAccount.getPlan().getFreeInternetDataUsageUnits())*(postpaidAccount.getPlan().getInternetDataUsageRate())):0.0f;
		float servicesTax=10;
		float totalBillAmount=localSMSAmount+stdSMSAmount+localCallAmount+stdCallAmount+internetDataUsageAmount+servicesTax;
		Bill bill=new Bill(billMonth, totalBillAmount, localSMSAmount, stdSMSAmount, localCallAmount, stdCallAmount, internetDataUsageAmount, servicesTax,postpaidAccount);
		bill=billingDAOServices.save(bill);
		System.out.println(bill);
		return bill.getBillID();
	}
	@Override
	public Customer getCustomerDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		Customer customer=customerDAOServices.findById(customerID).orElseThrow(()->new CustomerDetailsNotFoundException("Customer is not found."));
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() throws BillingServicesDownException {
		return customerDAOServices.findAll();
	}

	@Override
	public PostpaidAccount getPostPaidAccountDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		getCustomerDetails(customerID);
		PostpaidAccount postpaidAccount=postPaidDAOServices.findById(mobileNo).get();
		if(postpaidAccount==null) throw new PostpaidAccountNotFoundException("Post Paid Account does not exist");
		return postpaidAccount;
	}
	@Override
	public List<PostpaidAccount> getCustomerAllPostpaidAccountsDetails(int customerID)
			throws CustomerDetailsNotFoundException, BillingServicesDownException {
		List<PostpaidAccount> listOfPostPaidAccount=billingDAOServices.getCustomerPostPaidAccounts(customerID);
		return listOfPostPaidAccount;
	}

	@Override
	public Bill getMobileBillDetails(int customerID, long mobileNo, String billMonth)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, InvalidBillMonthException,
			BillDetailsNotFoundException, BillingServicesDownException {
		getCustomerDetails(customerID);
		getPostPaidAccountDetails(customerID, mobileNo);
		Bill bill=billingDAOServices.getMonthlyBill(billMonth, mobileNo);
		return bill;
	}

	@Override
	public List<Bill> getCustomerPostPaidAccountAllBillDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			BillDetailsNotFoundException {
		getCustomerDetails(customerID);
		List<Bill>listOfBill=billingDAOServices.getCustomerPostPaidAccountAllBills(mobileNo);
		return listOfBill;
	}

	@Override
	public boolean changePlan(int customerID, long mobileNo, int planID) throws CustomerDetailsNotFoundException,
			PostpaidAccountNotFoundException, PlanDetailsNotFoundException, BillingServicesDownException {
		getPostPaidAccountDetails(customerID, mobileNo);
		openPostpaidMobileAccount(customerID, planID);
		return true;
	}

	@Override
	public boolean closeCustomerPostPaidAccount(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException {
		getCustomerDetails(customerID);
		getPostPaidAccountDetails(customerID, mobileNo);
		postPaidDAOServices.deleteById(mobileNo);
		return true;
	}

	@Override
	public boolean deleteCustomer(int customerID)
			throws BillingServicesDownException, CustomerDetailsNotFoundException {
		getCustomerDetails(customerID);
		customerDAOServices.deleteById(customerID);
		return true;
	}

	@Override
	public Plan getCustomerPostPaidAccountPlanDetails(int customerID, long mobileNo)
			throws CustomerDetailsNotFoundException, PostpaidAccountNotFoundException, BillingServicesDownException,
			PlanDetailsNotFoundException {
		return (getPostPaidAccountDetails(customerID, mobileNo)).getPlan();
	}
	@Override
	public Plan savingNewPlanInTable(Plan plan){
		plan=planDAOServices.save(plan);
		return plan;
	}
}