package com.cg.demo;
import java.awt.List;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

class A{
	String a;
	A(String a){
		this.a=a;
	}
}

public class C{
	public static void main(String[] args) {
		String date=LocalDate.parse("2014-05-03-11-11-11").format(DateTimeFormatter.ISO_DATE_TIME);
		System.out.println(date);
	}
}
