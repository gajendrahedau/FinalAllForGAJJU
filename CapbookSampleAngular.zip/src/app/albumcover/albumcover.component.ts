import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { PhotoInterface } from '../AllInterFace/photo-interface';
@Component({
  selector: 'app-albumcover',
  templateUrl: './albumcover.component.html',
  styleUrls: ['./albumcover.component.css']
})
export class AlbumcoverComponent implements OnInit {
  emailID: string;
  allImageForCover:PhotoInterface[];
  errorCoverImage:string;
  constructor(private router: Router,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
    this.userAccountService.getAllImageForCover(this.emailID).subscribe(
      x => {
        this.allImageForCover=x;
      }
      ,
      y=>{
        this.errorCoverImage=y;
      }
     );
  }
  back(): void {
    this.router.navigate(['/photosComponent']);
  }
}
