import { UserAccount } from '../UserInterface/user-account';
export interface FriendList {
    friendEmailID:string;
    userAccount:UserAccount;
}
