import { UserAccount } from '../UserInterface/user-account';
export interface PhotoInterface {
    "photoId": string,
    "photoName": string,
    "photoType": string,
    "data":Blob;
    "userAccount":UserAccount;
}
