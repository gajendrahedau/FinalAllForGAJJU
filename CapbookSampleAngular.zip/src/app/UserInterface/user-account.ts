export interface UserAccount {
    emailID:string,
    firstName:string,
    lastName:string,
    password:string,
    gender:string,
    dob: string
}
