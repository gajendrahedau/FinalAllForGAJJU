import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthService } from '../AuthService/auth.service';
import { UseraccountService } from '../Services/useraccount.service';
import { UserAccount } from '../UserInterface/user-account';
import { PhotoInterface } from '../AllInterFace/photo-interface';
import { StatusInterface } from '../AllInterFace/status-interface';
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit { 
  public homepageComponent:string;
  userAccountDetails:UserAccount;
  emailID: string;
  errorEmail:string;
  errorSingleImage:string;
  errorAllImage:string;
  singlePhotoDetails:PhotoInterface;
  profilePhotoDetails:PhotoInterface;
  profilePhotoData:Blob;
  singlePhotoData:Blob;
  allPhotoDetails:PhotoInterface[];
  selectedFile: File;
  messagePhoto:string;
  erorMessagePhoto:string;
  statusMessage:string;
  allStatus:StatusInterface[];
  message:String;
  _personEmailID: string;
  get personEmailID():string{
    return this._personEmailID;
  } 
  set personEmailID(value: string){
    this._personEmailID = value;
  } 
  constructor(private router: Router,public authService: AuthService,public userAccountService:UseraccountService) { } 
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
    this.userAccountService.getUserAccountDetails(this.emailID).subscribe (
      userAccountDetails=>{
      this.userAccountDetails=userAccountDetails;
    },
    errorMessage=>{
      this.errorEmail="Email ID does not exist.";
    }
  );
  this.userAccountService.getNotification(this.emailID).subscribe(
    x=>{  
    },
    y=>{   
    }
  );
  this.userAccountService.getSingleImageForProfile(this.emailID).subscribe(
    x=>{
      this.profilePhotoDetails=x;   
      this.profilePhotoData=this.profilePhotoDetails.data;    
    },
    y=>{     
    }
  );
  this.userAccountService.getAllStatusForAllUser().subscribe(
      x=>{
        this.allStatus=x;
      },
      y=>{   
      }
    );
    this.userAccountService.getAllImageFromStorage().subscribe(
      x=>{
        this.allPhotoDetails=x;
      },
      y=>{      
      }
    );
}
 logout(): void {
    this.authService.logout();
    this.router.navigate(['/welcomeComponent']);
  }
  timeline(): void {
    this.router.navigate(['/timelineComponent']);
  }
  friendRequest(): void {
    this.router.navigate(['/friendrequestComponent']);
  }
   onFileChanged(event) {
    this.selectedFile = event.target.files[0];
    this.userAccountService.uploadUpdatePhoto(this.selectedFile,this.emailID).subscribe(
      m=>this.messagePhoto,
      er=>this.erorMessagePhoto
    );
  }
  statusPost(){
    this.userAccountService.uploadStatus(this.emailID,this.statusMessage).subscribe(
      x=>console.log(x),
      y=>console.log(y)
    );
  }
  search(): void{
    this.userAccountService.getUserAccountDetails(this.personEmailID).subscribe(
      userAccountDetails=>{
        this.userAccountDetails=userAccountDetails;
        if(this._personEmailID == this.userAccountDetails.emailID){
          localStorage.setItem('isLoggedIn', "true");
          localStorage.setItem('token1',this.userAccountDetails.emailID );
          this.router.navigate(['/friendprofileComponent']);
        }
        else{
          this.message = "Please check your email";
        }
      },
      errorMessage=>{
        this.message="Email ID does not exist.";
      }
    )
  }
}
