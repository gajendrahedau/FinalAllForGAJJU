import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyuploadComponent } from './myupload.component';

describe('MyuploadComponent', () => {
  let component: MyuploadComponent;
  let fixture: ComponentFixture<MyuploadComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyuploadComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
