import { Component, OnInit } from '@angular/core';
import { UseraccountService } from '../Services/useraccount.service';
@Component({
  selector: 'app-myupload',
  templateUrl: './myupload.component.html',
  styleUrls: ['./myupload.component.css']
})
export class MyuploadComponent implements OnInit {
 constructor(private userAccountService:UseraccountService) { }
  selectedFile: File;
  message:string;
  erormessage:string;
  ngOnInit() {
  }
  onFileChanged(event) {
    this.selectedFile = event.target.files[0]
  }
  onUpload() {
    const uploadData = new FormData();
    uploadData.append('myFile', this.selectedFile, this.selectedFile.name);
  }
}
