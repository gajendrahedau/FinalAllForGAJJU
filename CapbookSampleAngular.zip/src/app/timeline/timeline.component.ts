import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { UseraccountService } from '../Services/useraccount.service';
import { AuthService } from '../AuthService/auth.service';
import { UserAccount } from '../UserInterface/user-account';
import { PhotoInterface } from '../AllInterFace/photo-interface';
@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.css']
})
export class TimelineComponent implements OnInit {
  emailID: string;
  userAccountDetails:UserAccount;
  loading: boolean=true;
  errorEmail:string;
  errorProfilePhoto:string;
  profilePhotoDetails:PhotoInterface;
  profilePhotoData:Blob;
  coverPhotoDetails:PhotoInterface;
  coverPhotoData:Blob;
  selectedFile: File;
  messagePhoto1:string;
  erorMessagePhoto1:string;
  firstName:string;
  lastName:string;
  constructor(private router: Router,public authService: AuthService,public userAccountService:UseraccountService) { }
  ngOnInit() {
    this.emailID = localStorage.getItem('token');
    this.userAccountService.getUserAccountDetails(this.emailID).subscribe (
      x=>{   
      this.userAccountDetails=x;
      this.firstName=x.firstName;
      this.lastName=x.lastName;     
    },
    y=>{     
      this.errorEmail="Email ID does not exist.";
    }
  );
  this.userAccountService.getSingleImageForCover(this.emailID).subscribe(
    a=>{
      this.coverPhotoDetails=a;    
      this.coverPhotoData=this.coverPhotoDetails.data;     
    },
    b=>{     
    }
  );
  this.userAccountService.getSingleImageForProfile(this.emailID).subscribe(
    x=>{
      this.profilePhotoDetails=x;    
      this.profilePhotoData=this.profilePhotoDetails.data;      
    },
    y=>{    
    }
  );
}
  logout(): void {
    this.authService.logout();
    this.router.navigate(['/welcomeComponent']);
  }
  home(): void { 
    this.router.navigate(['/homepageComponent']);
  }
  settings(): void {   
    this.loading=false;
  }
  about(): void { 
    this.router.navigate(['/personaldetailsComponent']);
  }
  changePassword(): void {    
    this.router.navigate(['/changepasswordComponent']);
  }
  delete(): void {  
    this.router.navigate(['/deleteaccountComponent']);
  }
  photos(): void {  
    this.router.navigate(['/photosComponent']);
  }
  print(): void {
   }
   onUpdateProfile(event) {
    this.selectedFile = event.target.files[0];
    this.userAccountService.uploadProfilePhoto(this.selectedFile,this.emailID).subscribe(
      m=>this.messagePhoto1,
      er=>this.erorMessagePhoto1
    );  
  }
  onUpdateCover(event) {
    this.selectedFile = event.target.files[0];
    this.userAccountService.uploadCoverPhoto(this.selectedFile,this.emailID).subscribe(
      m=>this.messagePhoto1,
      er=>this.erorMessagePhoto1
    );
  }
  friends(): void {
    this.router.navigate(['/friendlistComponent']);
  }
}
