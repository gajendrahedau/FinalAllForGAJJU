import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FriendrequestacceptbuttonComponent } from './friendrequestacceptbutton.component';

describe('FriendrequestacceptbuttonComponent', () => {
  let component: FriendrequestacceptbuttonComponent;
  let fixture: ComponentFixture<FriendrequestacceptbuttonComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FriendrequestacceptbuttonComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FriendrequestacceptbuttonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
