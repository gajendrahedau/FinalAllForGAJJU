package com.cg.library.services;
import java.util.List;

import com.cg.library.beans.Book;
import com.cg.library.beans.Student;
import com.cg.library.beans.Transaction;
import com.cg.library.exceptions.BookNotFoundException;
import com.cg.library.exceptions.StudentDetailsNotFoundException;
public interface LibraryService {
	Student acceptStudentDetails(Student student);
	Student getStudentDetails(int studentID) throws StudentDetailsNotFoundException;
	Book getBookDetails(int bookID) throws BookNotFoundException;
	List<Book> getAllBookDetails();
	Transaction bookIssue(int studentID,int bookID)  throws BookNotFoundException,StudentDetailsNotFoundException;
	boolean deleteStudentDetails(int studentID) throws StudentDetailsNotFoundException;
	boolean deleteBookDetails(int bookID)  throws BookNotFoundException;
	Book saveBookDetails(Book book);
}
