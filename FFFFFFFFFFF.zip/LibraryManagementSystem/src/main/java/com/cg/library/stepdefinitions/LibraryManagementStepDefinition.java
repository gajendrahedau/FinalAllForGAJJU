package com.cg.library.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class LibraryManagementStepDefinition {
	private WebDriver driver;
	@Given("^Student is on 'Register Student page'$")
	public void student_is_on_Register_Student_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("http://localhost:1222/acceptStudentDetails");
	}
	@When("^Student enters his information Incorrectly$")
	public void student_enters_his_information_Incorrectly() throws Throwable {
		By by=By.name("firstName");
		WebElement login=driver.findElement(by);
		login.sendKeys("Gajendra");
		by=By.name("lastName");
		login=driver.findElement(by);
		login.sendKeys("Hedau");
		by=By.name("emailID");
		login=driver.findElement(by);
		login.sendKeys("gajju");
		by=By.name("phoneNo");
		login=driver.findElement(by);
		login.sendKeys("1234");
		login.click();
	}
	@Then("^Proper error message should be displayed$")
	public void proper_error_message_should_be_displayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Student Registration";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	@When("^Student enters his information correctly$")
	public void student_enters_his_information_correctly() throws Throwable {
		By by=By.name("firstName");
		WebElement login=driver.findElement(by);
		login.sendKeys("Gajendra");
		by=By.name("lastName");
		login=driver.findElement(by);
		login.sendKeys("Hedau");
		by=By.name("emailID");
		login=driver.findElement(by);
		login.sendKeys("gajju@gmail.com");
		by=By.name("phoneNo");
		login=driver.findElement(by);
		login.sendKeys("9852700640");
		by=By.xpath("//*[@id=\"student\"]/table/tbody/tr[5]/td/input");
		login=driver.findElement(by);
		login.click();
	}
	@Then("^Student should get his student ID$")
	public void student_should_get_his_student_ID() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="registration success";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
