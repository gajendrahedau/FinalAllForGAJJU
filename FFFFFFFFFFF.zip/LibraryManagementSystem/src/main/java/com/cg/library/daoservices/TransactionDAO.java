package com.cg.library.daoservices;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.library.beans.Transaction;

public interface TransactionDAO extends JpaRepository<Transaction,Integer>{

}
