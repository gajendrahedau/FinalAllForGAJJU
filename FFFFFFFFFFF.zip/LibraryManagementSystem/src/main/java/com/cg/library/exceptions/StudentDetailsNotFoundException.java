package com.cg.library.exceptions;

public class StudentDetailsNotFoundException extends Exception{

	public StudentDetailsNotFoundException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public StudentDetailsNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public StudentDetailsNotFoundException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public StudentDetailsNotFoundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public StudentDetailsNotFoundException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
}
