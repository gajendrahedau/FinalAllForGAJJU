package com.cg.library.daoservices;
import org.springframework.data.jpa.repository.JpaRepository;
import com.cg.library.beans.Student;
public interface StudentDAO extends JpaRepository<Student,Integer>{
}
