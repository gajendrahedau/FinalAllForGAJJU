package com.cg.project.stepdefinitions;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.PageFactory;

import com.cg.project.beans.LoginPage;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class GitHubSearchStepDefinition {
	private WebDriver driver;
	private LoginPage loginPage;
	@Given("^User is in on GitHub log in page$")
	public void user_is_in_on_GitHub_log_in_page() throws Throwable {
		System.setProperty("webdriver.chrome.driver","D:\\chromedriver.exe");
		driver=new ChromeDriver();
		driver.get("https://github.com/login");
		loginPage=PageFactory.initElements(driver, LoginPage.class);
	}
	@When("^User enters invalid username and valid password$")
	public void user_enters_invalid_username_and_valid_password() throws Throwable {
		/*By by1=By.name("login");
		WebElement login=driver.findElement(by1);
		login.sendKeys("dsgh");
		By by2=By.name("password");
		WebElement password=driver.findElement(by2);
		password.sendKeys("atulappu@123");
		By by3=By.name("commit");
		WebElement submit=driver.findElement(by3);
		submit.submit();
*/	
		loginPage.setUsername("gajendrahed");
		loginPage.setPassword("edtre");
		loginPage.clickSignIn();
	}
	@Then("^'Invalid Username ' message should be dislayed$")
	public void invalid_Username_message_should_be_dislayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Sign in to GitHub � GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	@When("^User enters valid username and Invalid password$")
	public void user_enters_valid_username_and_Invalid_password() throws Throwable {
		loginPage.setUsername("gajendrahedau");
		loginPage.setPassword("edtre");
		loginPage.clickSignIn();
	}
	@Then("^'Invalid Password' message should be dislayed$")
	public void invalid_Password_message_should_be_dislayed() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="Sign in to GitHub � GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
	@When("^User enters valid username and valid password$")
	public void user_enters_valid_username_and_valid_password() throws Throwable {
		loginPage.setUsername("gajendrahedau");
		loginPage.setPassword("atulappu@123");
		loginPage.clickSignIn();
	}
	@Then("^User's account should be opened$")
	public void user_s_account_should_be_opened() throws Throwable {
		String actualTitle=driver.getTitle();
		String expectedTitle="GitHub";
		Assert.assertEquals(expectedTitle, actualTitle);
		driver.close();
	}
}
