package com.cg.banking.stepdefinition;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
public class BankingSystemLogin {
	@Given("^User is on HomePage which is indexPage$")
	public void user_is_on_HomePage_which_is_indexPage() throws Throwable {
	}
	@When("^User enter his valid username and password$")
	public void user_enter_his_valid_username_and_password() throws Throwable {
	}
	@Then("^HomePage should be opened with deposit and credit option$")
	public void homepage_should_be_opened_with_deposit_and_credit_option() throws Throwable {
	}
}
