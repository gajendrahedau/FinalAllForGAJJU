package com.cg.banking.daoservices;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
public class AccountDAOImpl implements AccountDAO{
	private static Connection conn=GetConnection.getConnection();

	@Override
	public Account save(Account account) throws SQLException {
		try {
			conn.setAutoCommit(false);
			PreparedStatement pst=conn.prepareStatement("INSERT INTO Account12(accountNo,pinNumber,accountBalance,accountType,status) VALUES(accountNo.NEXTVAL,pinNo.NEXTVAL,?,?,?)");
			pst.setFloat(1,account.getAccountBalance());
			pst.setString(2, account.getAccountType());
			pst.setString(3,"Activated");

			pst.executeUpdate();

			PreparedStatement pst1=conn.prepareStatement("SELECT MAX(accountNo) from Account12");
			ResultSet rset=pst1.executeQuery();

			rset.next();
			long accountNo=rset.getLong(1);

			PreparedStatement pst2=conn.prepareStatement("SELECT MAX(pinNumber) from Account12");
			ResultSet rset1=pst2.executeQuery();

			rset1.next();
			int pinNumber=rset1.getInt(1);

			/*PreparedStatement ps1=conn.prepareStatement("INSERT INTO Transaction12(accountNo,transactionId,amount,transactionType) VALUES(?,transactionId.NEXTVAL,?,?)");
			ps1.setLong(1,accountNo);
			ps1.setFloat(2,account.getAccountBalance());
			ps1.setString(3,"Cash");
			ps1.executeUpdate();
			 */
			
			conn.commit();

			account.setAccountNo(accountNo);
			account.setPinNumber(pinNumber);

			return account;

		} catch (SQLException e) {
			conn.rollback();
			System.out.println("Services are down.");
			throw e;
		}
		finally{
			conn.setAutoCommit(true);
		}

	}

	@Override
	public Account creditAmount(long accountNo, float amount) {
		PreparedStatement ps1;
		try {
			ps1 = conn.prepareStatement("UPDATE Account12 SET accountBalance=((accountBalance)+?) WHERE accountNo="+accountNo);
			ps1.setFloat(1, amount);
			ps1.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Services are down");
		}
		return findOne(accountNo);
	}


	@Override
	public Account extractAmount(long accountNo, float amount) {
		PreparedStatement ps1;
		try {
			ps1 = conn.prepareStatement("UPDATE Account12 SET accountBalance=((accountBalance)-?) WHERE accountNo="+accountNo);
			ps1.setFloat(1, amount);
			ps1.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Services are down");
		}
		return findOne(accountNo);
	}

	@Override
	public Account findOne(long accountNo) {
		try {
			PreparedStatement ps=conn.prepareStatement("SELECT * FROM Account12 WHERE accountNo="+accountNo);
			ResultSet rs=ps.executeQuery();
			if(rs.next()){
				int pinNumber=rs.getInt("pinNumber");
				float accountBalance=rs.getFloat("accountBalance");
				String accountType=rs.getString("accountType");
				String status=rs.getString("status");

				Account account=new Account(pinNumber, accountType, status, accountBalance, accountNo, null);
				
				
				/*PreparedStatement ps2 = conn.prepareStatement("SELECT transactionId,amount,transactionType FROM Transaction12 WHERE accountNo="+accountNo);
				ResultSet rs2=ps2.executeQuery();
				
					int transactionId=rs2.getInt("transactionId");
					float amount=rs2.getFloat("amount");
					String transactionType=rs2.getString("transactionType");
					Transaction t=new Transaction(transactionId, amount, transactionType);
					account.setTransaction(t);*/
				
				return account;
			}
			return null;
		} catch (SQLException e) {
			e.getStackTrace();
			System.out.println("Services are down");
		}
		return null;
	}

	@Override
	public List<Account> findAll() {
		List<Account> list=new ArrayList<Account>();
		try {
			PreparedStatement ps=conn.prepareStatement("SELECT * FROM Account12");

			ResultSet rs=ps.executeQuery();
			while(rs.next()){
				long accountNo=rs.getLong("accountNo");
				int pinNumber=rs.getInt("pinNumber");
				float accountBalance=rs.getFloat("accountBalance");
				String accountType=rs.getString("accountType");
				String status=rs.getString("status");
				Account account=new Account(pinNumber, accountType, status, accountBalance, accountNo, null);
				list.add(account);
			}
			return list;

		} catch (SQLException e) {
			System.out.println("Services are down");
		}
		return null;
	}

	@Override
	public void saveTransactionForWithdraw(long accountNo, float amount) {
		try {
			PreparedStatement ps=conn.prepareStatement("INSERT INTO transaction12(accountNo,transactionId,amount,transactionType) VALUES(?,transactionId.NEXTVAL,?,?)");
			ps.setLong(1, accountNo);
			ps.setFloat(2, amount);
			ps.setString(3, "Withdraw");
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Services are down");
		}
	}
	@Override
	public void saveTransactionForDeposit(long accountNo, float amount) {
		try {
			PreparedStatement ps=conn.prepareStatement("INSERT INTO transaction12(accountNo,transactionId,amount,transactionType) VALUES(?,transactionId.NEXTVAL,?,?)");
			ps.setLong(1, accountNo);
			ps.setFloat(2, amount);
			ps.setString(3, "Deposit");
			ps.executeUpdate();
		} catch (SQLException e) {
			System.out.println("Services are down");
		}

	}
	@Override
	public List<Transaction> getTransactionAll(long accountNo) {
		PreparedStatement ps;
		List<Transaction> list=new ArrayList<>();
		try {
			ps = conn.prepareStatement("SELECT transactionId,amount,transactionType FROM Transaction12 WHERE accountNo="+accountNo);
			ResultSet rs=ps.executeQuery();
			while(rs.next()){
			//	long accountNo=rs.getLong("");
				int transactionId=rs.getInt("transactionId");
				float amount=rs.getFloat("amount");
				String transactionType=rs.getString("transactionType");
				Transaction t=new Transaction(transactionId, amount, transactionType);
				list.add(t);
			}
			return list;
		} catch (SQLException e) {
		}
		return null;
	}

	@Override
	public void changeStatus(long accountNo) {
		Account account=findOne(accountNo);
		try {
			PreparedStatement ps=conn.prepareStatement("UPDATE Account12 SET status=? WHERE accountNo="+accountNo);
			ps.setString(1, "Blocked");
			ps.executeUpdate();
		} catch (SQLException e) {
		}
	}

	@Override
	public int countTable(long accountNo)  {
		return 0;
	}


}
