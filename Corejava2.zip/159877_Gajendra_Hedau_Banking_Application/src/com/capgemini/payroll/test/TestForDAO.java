package com.capgemini.payroll.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class TestForDAO {

	@BeforeClass
	public void setUpTestEnv(){
		
	}
	
	@Test
	public void invalidAmountCheck(){
		
	}
	
	@Test
	public void validAmountCheck(){
		
	}
	
	@AfterClass
	public void tearDownTestEnv(){
		
	}
	
}
